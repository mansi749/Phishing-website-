document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert("This is a phishing simulation. Be cautious about entering sensitive information on websites without verifying their authenticity.");
});
